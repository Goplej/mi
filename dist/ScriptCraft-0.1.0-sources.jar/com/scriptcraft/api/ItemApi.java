package com.scriptcraft.api;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

/** Read-only view of an {@link ItemStack}, e.g. {@code player.getHeldItem()}. */
public final class ItemApi {

    private final ItemStack stack;

    public ItemApi(ItemStack stack) {
        this.stack = stack;
    }

    public boolean isEmpty() {
        return stack == null || stack.func_190926_b();
    }

    /** Registry name, e.g. {@code minecraft:diamond_sword}. */
    public String getName() {
        if (isEmpty()) {
            return "minecraft:air";
        }
        Item item = stack.func_77973_b();
        ResourceLocation name = Item.field_150901_e.func_177774_c(item);
        return name == null ? "unknown" : name.toString();
    }

    /** Display name, includes renames and enchantment-free formatting. */
    public String getDisplayName() {
        return isEmpty() ? "" : stack.func_82833_r();
    }

    public int getCount() {
        return isEmpty() ? 0 : stack.func_190916_E();
    }

    public int getMeta() {
        return isEmpty() ? 0 : stack.func_77952_i();
    }

    @Override
    public String toString() {
        return isEmpty() ? "ItemStack(air)" : "ItemStack(" + getName() + " x" + getCount() + ")";
    }
}
