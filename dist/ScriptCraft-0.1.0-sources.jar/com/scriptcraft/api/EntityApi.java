package com.scriptcraft.api;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLivingBase;

/** Read-only view of any entity, with {@link #remove()} as the only mutation. */
public final class EntityApi {

    private final Entity entity;

    public EntityApi(Entity entity) {
        this.entity = entity;
    }

    public boolean isValid() {
        return entity != null;
    }

    /** Custom name tag when set, otherwise the entity type. */
    public String getName() {
        if (entity == null) {
            return "";
        }
        String custom = entity.func_95999_t();
        if (custom != null && !custom.isEmpty()) {
            return custom;
        }
        return getType();
    }

    /** Registry name of the entity type, e.g. {@code minecraft:zombie}. */
    public String getType() {
        if (entity == null) {
            return "";
        }
        String name = EntityList.func_75621_b(entity);
        return name == null ? "unknown" : name;
    }

    public int getId() {
        return entity == null ? -1 : entity.func_145782_y();
    }

    public double getX() {
        return entity == null ? 0D : entity.field_70165_t;
    }

    public double getY() {
        return entity == null ? 0D : entity.field_70163_u;
    }

    public double getZ() {
        return entity == null ? 0D : entity.field_70161_v;
    }

    /** Current health, or -1 for entities that have none (items, minecarts, ...). */
    public double getHealth() {
        if (entity instanceof EntityLivingBase) {
            return ((EntityLivingBase) entity).func_110143_aJ();
        }
        return -1D;
    }

    public boolean isAlive() {
        return entity != null && !entity.field_70128_L;
    }

    public int getDimension() {
        return entity == null ? 0 : entity.field_71093_bK;
    }

    public void teleport(double x, double y, double z) {
        if (entity != null) {
            entity.func_70634_a(x, y, z);
        }
    }

    public void remove() {
        if (entity != null) {
            entity.func_70106_y();
        }
    }

    @Override
    public String toString() {
        return "Entity(" + getType() + "#" + getId() + ")";
    }
}
