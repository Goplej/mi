package com.scriptcraft.api;

import com.scriptcraft.core.GameRefs;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * {@code world} - blocks, entities and players of the world the script runs in.
 *
 * <p>The world is resolved on every call from the script owner, so a player who moves to the
 * Nether keeps working on the world they are in.
 */
public final class WorldApi {

    private final Object owner;

    /** @param owner the player that started the script, or {@code null} to use the server world */
    public WorldApi(Object owner) {
        this.owner = owner;
    }

    public boolean isAvailable() {
        return world() != null;
    }

    public boolean isClient() {
        World world = world();
        return world != null && world.field_72995_K;
    }

    public String getName() {
        World world = require();
        return world.func_72912_H().func_76065_j();
    }

    public int getDimension() {
        return require().field_73011_w.func_186058_p().func_186068_a();
    }

    public long getTime() {
        return require().func_72820_D();
    }

    public void setTime(long time) {
        require().func_72877_b(time);
    }

    public int getMaxHeight() {
        return require().func_72800_K();
    }

    public BlockInfo getBlock(double x, double y, double z) {
        World world = require();
        BlockPos pos = new BlockPos((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
        IBlockState state = world.func_180495_p(pos);
        Block block = state.func_177230_c();
        ResourceLocation name = Block.field_149771_c.func_177774_c(block);
        return new BlockInfo(
                name == null ? "unknown" : name.toString(),
                block.func_176201_c(state),
                pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
    }

    /** {@code world.setBlock(100, 64, 100, "minecraft:stone")} */
    public boolean setBlock(double x, double y, double z, String blockName) {
        return setBlock(x, y, z, blockName, 0);
    }

    /** {@code world.setBlock(100, 64, 100, "minecraft:stone", 1)} */
    public boolean setBlock(double x, double y, double z, String blockName, int meta) {
        World world = require();
        BlockPos pos = new BlockPos((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
        if (!inBounds(world, pos)) {
            return false;
        }
        IBlockState state = BlockLookup.lookup(blockName, meta);
        return world.func_175656_a(pos, state);
    }

    public boolean isAir(double x, double y, double z) {
        World world = require();
        BlockPos pos = new BlockPos((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
        return world.func_175623_d(pos);
    }

    public int getBlockId(double x, double y, double z) {
        World world = require();
        BlockPos pos = new BlockPos((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
        return Block.func_149682_b(world.func_180495_p(pos).func_177230_c());
    }

    public List<PlayerApi> getPlayers() {
        List<PlayerApi> players = new ArrayList<PlayerApi>();
        World world = require();
        for (EntityPlayer player : world.field_73010_i) {
            players.add(new PlayerApi(player));
        }
        return players;
    }

    /**
     * Every loaded entity. This can be a large list in a busy world - prefer
     * {@link #getEntitiesNear(double, double, double, double)} or {@code entities.getNearby()}.
     */
    public List<EntityApi> getEntities() {
        List<EntityApi> entities = new ArrayList<EntityApi>();
        for (Entity entity : require().func_72910_y()) {
            entities.add(new EntityApi(entity));
        }
        return entities;
    }

    public List<EntityApi> getEntitiesNear(double x, double y, double z, double radius) {
        List<EntityApi> result = new ArrayList<EntityApi>();
        double squared = radius * radius;
        for (Entity entity : require().func_72910_y()) {
            double dx = entity.field_70165_t - x;
            double dy = entity.field_70163_u - y;
            double dz = entity.field_70161_v - z;
            if (dx * dx + dy * dy + dz * dz <= squared) {
                result.add(new EntityApi(entity));
            }
        }
        return result;
    }

    /** Replaces World.isValid, which is private in 1.12.2. */
    private static boolean inBounds(World world, BlockPos pos) {
        return pos.func_177956_o() >= 0 && pos.func_177956_o() < world.func_72800_K()
                && Math.abs(pos.func_177958_n()) < 30000000 && Math.abs(pos.func_177952_p()) < 30000000;
    }

    private World require() {
        World world = world();
        if (world == null) {
            throw new IllegalStateException("No world available. Scripts need a running world - join one first.");
        }
        return world;
    }

    private World world() {
        return GameRefs.worldFor(owner);
    }
}
